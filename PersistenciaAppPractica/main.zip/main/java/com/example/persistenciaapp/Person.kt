package com.example.persistenciaapp

data class Person(
    val name: String,
    val description: String,
    val imageResId: Int
)

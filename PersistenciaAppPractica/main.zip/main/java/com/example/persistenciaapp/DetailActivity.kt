package com.example.persistenciaapp

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val name = intent.getStringExtra("name")
        val description = intent.getStringExtra("description")
        val imageResId = intent.getIntExtra("imageResId", R.drawable.travis)

        val imageView: ImageView = findViewById(R.id.detailImage)
        val nameView: TextView = findViewById(R.id.detailName)
        val descView: TextView = findViewById(R.id.detailDescription)

        imageView.setImageResource(imageResId)
        nameView.text = name
        descView.text = description
    }
}

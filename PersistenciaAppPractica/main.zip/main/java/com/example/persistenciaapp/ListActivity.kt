package com.example.persistenciaapp

import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ListActivity : AppCompatActivity() {

    private lateinit var peopleList: List<Person>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        val prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        val userName = prefs.getString("username", "Usuario")

        val textUser: TextView = findViewById(R.id.textUser)
        textUser.text = "Hola, $userName"

        val listView: ListView = findViewById(R.id.listView)

        peopleList = listOf(
            Person("profile1", "Estudiante de ingeniería", R.drawable.profile1),
            Person("travis", "Diseñadora gráfica", R.drawable.travis),
            Person("profile2", "Desarrollador Android", R.drawable.profile2)
        )

        val adapter = PersonAdapter(this, peopleList)
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedPerson = peopleList[position]
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("name", selectedPerson.name)
            intent.putExtra("description", selectedPerson.description)
            intent.putExtra("imageResId", selectedPerson.imageResId)
            startActivity(intent)
        }
    }
}

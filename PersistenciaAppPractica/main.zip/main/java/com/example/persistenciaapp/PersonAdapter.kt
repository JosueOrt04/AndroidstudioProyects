package com.example.persistenciaapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class PersonAdapter(private val context: Context, private val people: List<Person>) : BaseAdapter() {
    override fun getCount(): Int = people.size
    override fun getItem(position: Int): Any = people[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val item = people[position]
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_person, parent, false)

        val imageView: ImageView = view.findViewById(R.id.imageView)
        val nameView: TextView = view.findViewById(R.id.textName)
        val descView: TextView = view.findViewById(R.id.textDescription)

        imageView.setImageResource(item.imageResId)
        nameView.text = item.name
        descView.text = item.description

        return view
    }
}

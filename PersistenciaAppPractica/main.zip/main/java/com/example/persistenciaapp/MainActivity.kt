package com.example.persistenciaapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editName: EditText
    private lateinit var buttonSave: Button
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editName = findViewById(R.id.editName)
        buttonSave = findViewById(R.id.buttonSave)
        prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE)

        // Recuperar el nombre guardado
        val savedName = prefs.getString("username", "")
        editName.setText(savedName)

        buttonSave.setOnClickListener {
            val name = editName.text.toString()
            prefs.edit().putString("username", name).apply()

            // Ir a la lista
            startActivity(Intent(this, ListActivity::class.java))
        }
    }
}

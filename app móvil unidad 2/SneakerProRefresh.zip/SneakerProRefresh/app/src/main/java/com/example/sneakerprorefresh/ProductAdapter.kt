package com.example.sneakerprorefresh

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.sneakerprorefresh.databinding.ItemProductBinding
import java.text.NumberFormat
import java.util.Locale

class ProductAdapter(
    private var items: MutableList<Product>
) : RecyclerView.Adapter<ProductAdapter.Holder>() {

    fun submit(list: List<Product>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val binding = ItemProductBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return Holder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(items[position])

    inner class Holder(private val b: ItemProductBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(p: Product) {
            b.name.text = p.name
            b.desc.text = p.description
            val nf = NumberFormat.getCurrencyInstance(Locale("es","MX"))
            b.price.text = nf.format(p.price)
            b.img.load(p.image)

            b.btnBuy.setOnClickListener {
                Toast.makeText(b.root.context, "Agregado: ${p.name}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

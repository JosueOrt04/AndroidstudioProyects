package com.example.sneakerprorefresh

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.example.sneakerprorefresh.databinding.ActivityMainBinding
import org.json.JSONArray
import java.io.BufferedReader
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var adapter: ProductAdapter
    private var allProducts: List<Product> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        setSupportActionBar(b.toolbar)

        adapter = ProductAdapter(mutableListOf())
        b.recycler.layoutManager = GridLayoutManager(this, 2)
        b.recycler.adapter = adapter

        // Swipe to refresh
        b.swipeRefresh.setOnRefreshListener {
            refreshList()
        }

        // Toolbar refresh icon
        b.toolbar.setOnMenuItemClickListener {
            if (it.itemId == R.id.action_refresh) {
                refreshList()
                true
            } else false
        }

        // Load catalog from assets
        allProducts = loadProducts()
        refreshList()
    }

    private fun refreshList() {
        // Shuffle and take random slice to look "different"
        val shuffled = allProducts.shuffled(Random(System.currentTimeMillis()))
        val take = (6..10).random()
        adapter.submit(shuffled.take(take))
        b.swipeRefresh.isRefreshing = false
    }

    private fun loadProducts(): List<Product> {
        val input = assets.open("products.json")
        val text = input.bufferedReader().use(BufferedReader::readText)
        val arr = JSONArray(text)
        val list = mutableListOf<Product>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Product(
                    id = o.getInt("id"),
                    name = o.getString("name"),
                    description = o.getString("description"),
                    price = o.getDouble("price"),
                    image = o.getString("image")
                )
            )
        }
        return list
    }
}

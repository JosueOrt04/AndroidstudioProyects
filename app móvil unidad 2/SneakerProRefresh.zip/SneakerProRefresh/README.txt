Proyecto: SneakerProRefresh
--------------------------------
- Título en toolbar: "Sneaker Pro Store"
- Botón de refresh en la parte superior (ícono girar) y también pull-to-refresh.
- Más tenis en assets/products.json. Cada refresh baraja y muestra un set distinto.
- Diseño con MaterialCardView, imagen, nombre, descripción, precio y botón "Comprar".

Cómo abrir:
1) Android Studio > File > Open > Selecciona la carpeta SneakerProRefresh
2) Compilar y correr (minSdk 21, targetSdk 34).

Cambios rápidos:
- Texto superior: res/values/strings.xml (store_tagline)
- Nombre de la app: res/values/strings.xml (app_name)
- Colores/Tema: res/values/colors.xml y res/values/themes.xml
- Catálogo: app/src/main/assets/products.json

package com.example.myapplication_segundo_pio

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Botón para cambiar de pantalla (sin datos)
        val btnCambiarPantalla = findViewById<Button>(R.id.btnCambiarPantalla)
        btnCambiarPantalla.setOnClickListener {
            val intent = Intent(this, SegundaActivity::class.java)
            startActivity(intent)
        }

        // ✅ Botón para enviar datos a SegundaActivity
        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etEdad = findViewById<EditText>(R.id.etEdad)
        val btnEnviarDatos = findViewById<Button>(R.id.btnEnviarDatos)

        btnEnviarDatos.setOnClickListener {
            val nombre = etNombre.text.toString()
            val edad = etEdad.text.toString()

            val intent = Intent(this, SegundaActivity::class.java)
            intent.putExtra("nombre", nombre)
            intent.putExtra("edad", edad)
            startActivity(intent)
        }

        val btnAbrirNavegador = findViewById<Button>(R.id.btnAbrirNavegador)
        btnAbrirNavegador.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = android.net.Uri.parse("https://www.google.com")
            startActivity(intent)
        }

        val btnValidarCampos = findViewById<Button>(R.id.btnValidarCampos)


        btnValidarCampos.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val edad = etEdad.text.toString().trim()

            if (nombre.isEmpty()) {
                etNombre.error = "Por favor ingresa tu nombre"
                etNombre.requestFocus()
                return@setOnClickListener
            }

            if (edad.isEmpty()) {
                etEdad.error = "Por favor ingresa tu edad"
                etEdad.requestFocus()
                return@setOnClickListener
            }

            // Si pasó la validación, enviamos a SegundaActivity
            val intent = Intent(this, SegundaActivity::class.java).apply {
                putExtra("nombre", nombre)
                putExtra("edad", edad)
            }
            startActivity(intent)
        }




    }
}

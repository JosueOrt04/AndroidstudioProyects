package com.example.myapplication_segundo_pio

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SegundaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda)

        val tvNombre = findViewById<TextView>(R.id.tvNombreRecibido)
        val tvEdad = findViewById<TextView>(R.id.tvEdadRecibida)

        // Recuperar datos del intent
        val nombre = intent.getStringExtra("nombre") ?: "No recibido"
        val edad = intent.getStringExtra("edad") ?: "No recibida"

        tvNombre.text = getString(R.string.nombre_recibido) + nombre
        tvEdad.text = getString(R.string.edad_recibida) + edad
    }
}

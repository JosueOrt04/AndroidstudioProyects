package com.example.diseodeperfilapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class LinearRelativeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_linear_relative)
    }
}

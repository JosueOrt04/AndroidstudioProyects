package com.example.diseodeperfilapp

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Permitir rotación automática en todas las posiciones (vertical y horizontal)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR

        setContentView(R.layout.activity_main)

        val imageView = findViewById<ImageView>(R.id.profileImage)

        Glide.with(this)
            .load("https://i.pravatar.cc/300")
            .into(imageView)
    }
}
